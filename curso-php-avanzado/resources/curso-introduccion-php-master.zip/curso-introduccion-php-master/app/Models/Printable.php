<?php
namespace App\Models;

interface Printable {
    public function getDescription();
}